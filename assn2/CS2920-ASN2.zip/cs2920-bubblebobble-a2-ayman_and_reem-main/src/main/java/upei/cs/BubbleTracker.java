package upei.cs;
import java.util.Arrays;

/**
 * Class to track the two middle players:
 * 1. the lowest ranked player (best) amoung the half of players that are highest ranked (worst)
 *  (best of the worst)
 *
 * 2. the highest ranked player (worst) amoung the half of players that are lowest ranked (best)
 *  (worst of the best)
 *
 *  Remember if there is an odd number of players then the median player is considered to
 *  be the worst of the best.
 *
 *  Remember: low rankings are good, high rankings are bad.
 *
 *  DO NOT alter the method headers for the public constructor,
 *  nor put or bestOfTheWorst or worstOfTheBest methods
 *
 *  Unit-testing relies on their exact method header matching their original state
 *
 */
public class BubbleTracker {

    /**
     * Public Constructor Don't change this
     */
    public BubbleTracker() {

    }

    Player[] players = new Player[25000]; //array that stores 25000 players
    int counter = 0; // counter that increments whenever a player is added
    boolean isSorted; // if the array it's sorted it's set to true otherwise it's false

    /**
     * Put a player with name and rank into the data structure
     * requires the player.name and player.rank are distinct
     * @param player the player being inserted into the data structure
     */
    public void put(Player player){
        players[counter] = player; // inserting the player in the array
        counter++;
        isSorted = false; // a new player was added so the array is not sorted
    }

    /**
     * Return the name of the driver who has the best ranking (lowest numeric value)
     * in the bottom half of all drivers.
     *
     * In the case of an odd number of drivers (>=3) this will return the ranking immediately worse (higher value)
     * than the median value. In the case of 1 driver only, that driver will be returned.
     *
     * Recall that the best possible ranking is 1 and higher numbers translate into worse rankings
     *
     * @return the best ranking player (lowest numeric score) in the bottom 50\% of player or empty string in the case their
     * is no such player
     */
    public String bestOfTheWorst(){

        // return an empty string if counter is 0 or 1
        if (counter == 0 || counter == 1){
            return "";
        }
        // if the array is not sorted
        if(!isSorted){
            Arrays.sort(players, 0, counter); // sort it
            isSorted = true; // set isSorted to true
        }

        // if counter is even return the middle player name
        if(counter % 2 == 0){
            return players[counter/2].name();
        }
        // else return next to middle (the middle player + 1) name
        else{
            return players[(counter/2) + 1].name();
        }
    }

    /**
     * Return the name of the player who has the poorest ranking (largest numerical ranking number)
     * in the top half of all players.
     *
     * In the case there are an odd number of players
     * this will return the exact median unless there is only one driver
     * in which case this returns empty string.
     *
     * Recall the top ranked player possible has ranking 1
     * @return the worst ranking player in the top 50\% of players or empty string if
     * no such driver exists
     */
    public String worstOfTheBest() {

        // return empty string if counter is 0
        if (counter == 0){
            return "";
        }

        // if counter is 2 return the name of the first player name
        if (counter == 2){
            return players[0].name();

        }

        // if the array is not sorted
        if(!isSorted){
            Arrays.sort(players, 0, counter); // sort it
            isSorted = true; // set isSorted to true
        }

        // if even return the name previous to the middle (the middle player - 1) name
        if(counter % 2 == 0){
            return players[(counter/2)-1].name();
        // else return middle player name
        } else{
            return players[(counter/2)].name();
        }
    }
}
