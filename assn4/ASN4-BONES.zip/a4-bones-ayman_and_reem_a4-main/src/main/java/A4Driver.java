import java.util.*;
import edu.princeton.cs.algs4.*;

/**
 * Driver program reading from stdin and writing to stdout
 * solves the archeology assignment 4.
 *
 * To run this use gradle run, or click the run button beside
 * any of the tests in the A4DriverTest class
 *
 */
public class A4Driver {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in); // scanner object
        int bonesFound = Integer.parseInt(sc.nextLine()); // variable that takes the first line of the txt file aka the number of bones found
        Digraph bonesGraph = new Digraph(bonesFound); // bonesGraph object
        ArrayList<String> bones = new ArrayList<>(bonesFound); // ArrayList that stores bone names. It has an initial capacity of the number of bones found

        // String declarations
        String bonesOrdering;
        String[] boneSplit;
        String boneName;

        // while loop that processes the txt file by adding bone names to the arraylists and adding the edges to the graph
        while (sc.hasNextLine()){

            // if bones found is 0, proceed.
            if (bonesFound != 0){
                boneName = sc.nextLine(); // read bone name
                bones.add(boneName); // add it to the arraylist
                bonesFound--; // decrement bones found

            }
            // if bones are 0 then read nextLine split it using "rests on"and add the edge to the graph
            else {
                bonesOrdering = sc.nextLine();
                boneSplit = bonesOrdering.split(" rests on ");
                bonesGraph.addEdge(bones.indexOf(boneSplit[0]), bones.indexOf(boneSplit[1]));
            }
        }

        Topological topological = new Topological(bonesGraph); // topological sort object

        // check if it has an order
        if (topological.hasOrder()){
            topological.order().forEach(i -> System.out.println(bones.get(i))); //print the bones in order
        } else {
            System.out.println("impossible"); // else print impossible
        }
    }

}