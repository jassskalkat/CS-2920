# Assignment 1 (Part 1) Daedalus' Last Hoorah 

This assignment involves familiarizing yourself with the IntelliJ IDEA environment and debugger and making sure everyone is comfortable with linked data structures and how they are arranged in memory. In addition, it requires a display of basic competency around pushing information to your code repository.

## First Task

In `Main.java` update the REPO_NAME variable to be set to the name of your repository. eg. `cs2920-a1-mygroup`

*this is important because the code will build a custom maze for each person based on this variable. **Therefore do not proceed with the assignment until this is set.** The graders will examine this variable and will compare your solution to the solution required for the proper setting of this variable.*

## Remaining Tasks

You are given java code that will create a maze of linked cells. Each cell in the maze has some number of doors that lead to another cell and the cell may contain one of a: sword, ring or a scary minotaur (whoa).

*Oops Github can't render the below yet (leaving it in anyways incase you view this in another editor that can render mermaid diagrams):*
```mermaid
graph TD;
    A[Start: EMPTY]-- Red Door -->B[RING];
    B-- Green Door --> A;
    A-- Blue Door -->C[MINOTAUR];
    C-- Yellow Door-->A;
    B-- Yellow Door -->D[EMPTY];
    D-- Blue Door -->B;
    C-- Blue Door -->D;
    D-- Yellow Door --> C;
    D-- Red Door -->E[SWORD];
    E-- Green Door -->D;
    E-- Blue Door -->A;
    A-- Yellow Door -->E;
```
![sample maze picture](https://g.gravizo.com/svg?digraph%20G%20%7B%0A%20%20%20%20size%20%3D%2215%2C15%22%3B%0A%20%20%20%20Start_EMPTY%20-%3E%20RING%20%5Blabel%3D%22Red%20Door%22%5D%3B%0A%20%20%20%20RING%20-%3E%20Start_EMPTY%20%5Blabel%3D%22Green%20Door%22%5D%3B%0A%20%20%20%20Start_EMPTY%20-%3E%20MINOTAUR%20%5Blabel%3D%22Blue%20Door%22%5D%3B%0A%20%20%20%20MINOTAUR%20-%3E%20Start_EMPTY%20%5Blabel%3D%22Yellow%20Door%22%5D%3B%0A%20%20%20%20RING%20-%3E%20EMPTY%20%5Blabel%3D%22Yellow%20Door%22%5D%3B%0A%20%20%20%20EMPTY%20-%3E%20RING%20%5Blabel%3D%22Blue%20Door%22%5D%3B%0A%20%20%20%20EMPTY%20-%3E%20SWORD%20%5Blabel%20%3D%22Red%20Door%22%5D%3B%0A%20%20%20%20SWORD%20-%3E%20EMPTY%5Blabel%3D%22Green%20Door%22%5D%3B%0A%20%20%20%20EMPTY%20-%3E%20MINOTAUR%5Blabel%3D%22Yellow%20Door%22%5D%3B%0A%20%20%20MINOTAUR-%3EEMPTY%5Blabel%3D%22Blue%20Door%22%5D%3B%0A%20%20%20SWORD%20-%3E%20Start_EMPTY%5Blabel%3D%22Blue%20Door%22%5D%3B%0A%20%20%20Start_EMPTY%20-%3E%20SWORD%5Blabel%3D%22Yellow%20Door%22%5D%3B%0A%20%20%7D)


Your task is to use the debugger and from a given starting location follow a path of doors leading around the maze such that you collect one of each of the sword, ring and minotaur (minotaurs are actually easy to carry so don't worry too much about this).

There are two mazes that you must solve. Once you have solved the maze, update the Main.java file to contain a String giving the sequence of doors (capitalized first letter of the door: e.g. BR for blue door followed by red door) you followed to solve the maze. Do this for each of the grid and complex mazes.

An example solution could be:

`RGBY`

This translates as take the RED door into a new cell then from that cell take the GREEN door, then the BLUE door and finally the YELLOW door.

There is a validation method that will follow the path you specify and determine if all of the items are found.

Here is a link to a YouTube video showing what you are expected to do:

[YouTube walkthrough](https://youtu.be/mEYT7lt75Ho)

## Grading

- Correct solution for grid maze? X/1
- Correct solution for complex maze? X/1

= Total grade X/2

This assignment should get everyone comfortable with the IntelliJ IDE and submitting / working on code with Github. This is less work than on a typical assignment, therefore this will only constitute part of an assignment. i.e., it will contribute 2 points towards your final grade and the other 3 points of the typical 5 point assignments will come in the next parts of the assignment ... to be released in the future.
