

import upei.cs2920.daedalus.*;

public class Main {

    //TODO: ALTER THE THREE STRINGS BELOW TO COMPLETE THE ASSIGNMENT
    //The name of your repository
    //should be something like cs2920-a1-groupname
    public static String REPO_NAME = "<cs2920-a1-javacoders>";

    //The doors along the path to retrieve all 3 items in the maze
    //should be something like: "RBBG..."
    public static String GRID_SOLUTION = "YYGGGRRRBGGBGYBRRBGG";
    public static String COMPLEX_SOLUTION = "BGRBGYYGBBGYRRB";

    public static boolean testGridMaze() {
        Cell start = MazeBuilder.mazeFor(REPO_NAME);
        int doorCount = start.doors.size();
        /* Set a breakpoint on the next line to explore your maze! */
        System.out.println("You are in a room in a maze.\n" +
                "There are " + doorCount + " door(s). Follow the doors to collect:\n" +
                "- RING\n" +
                "- SWORD\n" +
                "- MINOTAUR.\nDescribe the doors you follow to collect all 3 and win the game!");

        return Helper.isValidSolution(start, GRID_SOLUTION);
    }

    public static boolean testComplexMaze() {
        Cell start = MazeBuilder.complexMazeFor(REPO_NAME);
        int doorCount = start.doors.size();
        /* Set a breakpoint on the next line to explore your maze! */
        System.out.println("You are in a room in a complex maze.\n" +
                "There are " + doorCount + " door(s). Follow the doors to collect:\n" +
                "- RING\n" +
                "- SWORD\n" +
                "- MINOTAUR.\nDescribe the doors you follow to collect all 3 and win the game!");

        return Helper.isValidSolution(start, COMPLEX_SOLUTION);
    }

    public static void main(String[] args) {

        if (testGridMaze()) {
            System.out.println("Congrats, you found all the items");
        }
        else {
            System.out.println("Oops still stuck in the grid maze");
        }

        if (testComplexMaze()) {
            System.out.println("Congrats, you found all the items");
        }
        else {
            System.out.println("Oops still stuck in the complex maze");
        }
    }

}
