import org.junit.jupiter.api.Test;
import upei.cs2920.daedalus.*;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @Test
    void alwaysPassesTest() {
        //do nothing it will pass
    }

    @Test
    void testStringsChangedFromDefault() {
        assertNotEquals("cs2920-a1-javacoders", Main.REPO_NAME);
        //assertNotEquals("", Main.GRID_SOLUTION);
        //assertNotEquals("", Main.COMPLEX_SOLUTION);
    }

    @Test
    void testGridMazeSolution() {
        Cell cell = MazeBuilder.mazeFor(Main.REPO_NAME);
        boolean test = Helper.isValidSolution(cell, Main.GRID_SOLUTION);
        assertTrue(test);
    }

    @Test
    void testComplexMazeSolution() {
        Cell cell = MazeBuilder.complexMazeFor(Main.REPO_NAME);
        boolean test = Helper.isValidSolution(cell, Main.COMPLEX_SOLUTION);
        assertTrue(test);
    }

}
