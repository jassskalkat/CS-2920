import upei.cs2920.daedalus.*;
import java.util.*;

/**
 * Solve a daedalus maze to produce a door path leading to all three
 * items of interest: Minotaur, Ring and Sword
 */
public class DaedalusSolver {

    /**
     * Construct a DaedalusSolver object
     */
    public DaedalusSolver() {

    }

    /**
     * return a String representing the path of doors to go through that
     * leads from the starting cell of a maze such that the path will lead through
     * cells containing all 3 of the items of interest (Minotaur, Ring and Sword)
     * @param start the starting cell or entry point into the maze
     * @return A String giving the sequence of doors on the path
     * @throws IllegalArgumentException if a path leading to all 3 special items cannot be found
     */
    public String solve(Cell start) {

        StringBuilder mazePath = new StringBuilder();
        int chosenDoor, currentIndexForSet, loopCounter = 0;
        Set<Contents> itemsToCollect = new HashSet<>();
        Set<Door> doors;

        // While loop that will break either when all
        // items are found or if the counter exceeds 100000
        while (true){

            // Checks whether the current Cell has an item or it's empty.
            if (!start.contents.equals(Contents.EMPTY)) {
                itemsToCollect.add(start.contents);
            }

            // If else block that will randomly pick the door to enter and
            // chosenDoor represents the index of the door in the doors Set.
            if (start.doors.size() == 1){
                chosenDoor = 0;
            }else{
                chosenDoor = (int) (Math.random() * (start.doors.size()));
            }

            currentIndexForSet = 0;
            doors = start.doors.keySet();


            // Loop through the doors keySet until the currentIndexForSet matches the chosenDoor.
            for (Door door : doors) {
                if (currentIndexForSet == chosenDoor) {
                    mazePath.append(door.name().charAt(0)); // Append the first letter of the door color to the path.
                    start = start.doors.get(door); // Move to the next cell by entering the randomly selected door.
                    break;
                } else {
                    currentIndexForSet++;
                }
            }


            // Loop will end if all items are collected
            // Or if the counter exceeds 100000 loop with an Exception thrown.
            if (itemsToCollect.size() == 3) {
                break;
            } else if (loopCounter == 100000) {
                throw new IllegalArgumentException("Maze is unsolvable");
            }
            loopCounter++;
        }

        // returns the maze path.
        return mazePath.toString();

    }

}
