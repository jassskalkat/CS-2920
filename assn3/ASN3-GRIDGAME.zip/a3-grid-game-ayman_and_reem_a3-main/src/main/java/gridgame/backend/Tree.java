package gridgame.backend;

import gridgame.controller.ColorTemplate;


import java.awt.Color;
import java.util.*;
import java.util.function.BinaryOperator;

/**
 *
 * The QuadTree was implemented using Arraylists in order to get this shape: [Parent, Child1, Child2, Child3, Child4]
 * Rotate and player 2 are not coded.
 * We know that our code is not finished and we are hoping to get partial marks for what we wrote.
 * Thank you :)
 */



//based on a Quad Tree
public class Tree {
    public static final int MAX_SIZE = 512;
    ArrayList<DrawableBlock> list = new ArrayList<>();
    HashMap<DrawableBlock, String[]> blockHM = new HashMap<>();
    ArrayList<Integer> sizes = new ArrayList<>();
    Set<DrawableBlock> visited = new HashSet<>();
    boolean cwSwitch = false;
    boolean ccwSwitch = false;
    int isACorner = 0;
    private final int startingPower = 10;
    private int maxLevel;
    private int scoreP1 = 0;

    /**
     * public constructor
     * make sure to use ColorTemplate.instance().randomColorPicker() if you need
     * to generate any colors for your squares
     * @param mxLevels the maximum allowable number of levels in the tree
     *                 ex: if mxLevels is 1 then the tree can only have a root (with no children)
     */
    public Tree(int mxLevels) {
        this.maxLevel = mxLevels;

        Color color = ColorTemplate.instance().randomColorPicker();
        DrawableBlock drawableBlock = new DrawableBlock(0, 0, MAX_SIZE, color , true, true);
        list.add(drawableBlock);
        sizes.add(MAX_SIZE);
        blockHM.put(drawableBlock, new String[]{"NW", "Not Smashed"});
        blockHM.put(new DrawableBlock(0, 0, MAX_SIZE, color, false, true), new String[]{"NW", "Not Smashed"});
        blockHM.put(new DrawableBlock(0, 0, MAX_SIZE, color, true, false), new String[]{"NW", "Not Smashed"});
        blockHM.put(new DrawableBlock(0, 0, MAX_SIZE, color, false, false), new String[]{"NW", "Not Smashed"});

    }
    //PUBLIC INTERFACE

    /**
     * break the block signified by the cursor into 4 children with random colors
     * make sure to use ColorTemplate.instance().randomColorPicker() if you need
     * to generate any colors for your squares. in the case the tree already has mxLevels this
     * method does nothing
     */
    public void smash(){

        DrawableBlock NW;
        DrawableBlock NE;
        DrawableBlock SE;
        DrawableBlock SW;
        DrawableBlock Parent;
        for (DrawableBlock db : list){
            if(db.isSelected()){
                int mySize = db.size() / 2;
                if(getBlockLevel(db) < maxLevel && blockHM.get(db)[1].equalsIgnoreCase("Not Smashed")){

                    int indx = list.indexOf(db);


                    NW = new DrawableBlock(db.x(), db.y(), mySize, ColorTemplate.instance().randomColorPicker(), true, true);
                    NE = new DrawableBlock(db.x() + mySize, db.y(), mySize, ColorTemplate.instance().randomColorPicker(), true, false);
                    SE = new DrawableBlock(db.x() + mySize,db.y() + mySize, mySize, ColorTemplate.instance().randomColorPicker(), true, false);
                    SW = new DrawableBlock(db.x(),db.y() + mySize ,mySize, ColorTemplate.instance().randomColorPicker(), true, false);
                    Parent = new DrawableBlock(db.x(), db.y(), db.size(), db.color(), false, false);


                    list.add(indx + 1, NW);
                    list.add(indx + 2, NE);
                    list.add(indx + 3, SE);
                    list.add(indx + 4, SW);
                    list.set(indx, Parent);


                    blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), true, true),new String[]{"NW", "Not Smashed"});
                    blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), true, true),new String[]{"NE", "Not Smashed"});
                    blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), true, true),new String[]{"SE", "Not Smashed"});
                    blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), true, true),new String[]{"SW", "Not Smashed"});

                    blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), true, false),new String[]{"NW", "Not Smashed"});
                    blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), true, false),new String[]{"NE", "Not Smashed"});
                    blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), true, false),new String[]{"SE", "Not Smashed"});
                    blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), true, false),new String[]{"SW", "Not Smashed"});

                    blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), false, true),new String[]{"NW", "Not Smashed"});
                    blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), false, true),new String[]{"NE", "Not Smashed"});
                    blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), false, true),new String[]{"SE", "Not Smashed"});
                    blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), false, true),new String[]{"SW", "Not Smashed"});

                    blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), false, false),new String[]{"NW", "Not Smashed"});
                    blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), false, false),new String[]{"NE", "Not Smashed"});
                    blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), false, false),new String[]{"SE", "Not Smashed"});
                    blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), false, false),new String[]{"SW", "Not Smashed"});

                    blockHM.replace(db, new String[]{blockHM.get(db)[0], "Smashed"});

                    sizes.add(mySize);
                    cwSwitch = false;
                    ccwSwitch = false;

                    if(visited.contains(db)){
                        if(isACorner != 0){

                            visited.remove(db);
                            scoreP1 = scoreP1 - (db.size()*(2));


                        }else {
                            visited.remove(db);
                            scoreP1 = scoreP1 - db.size();
                        }
                    }
                    isACorner = 0;

                    break;

                }else if(blockHM.get(db)[1].equalsIgnoreCase("Smashed")){


                    int indx = list.indexOf(db);


                    list.set(list.indexOf(db) + 1, new DrawableBlock(list.get(list.indexOf(db)+1).x(),list.get(list.indexOf(db)+1).y(), list.get(list.indexOf(db)+1).size(), list.get(list.indexOf(db)+1).color(), true, false));
                    list.set(list.indexOf(db) + 2, new DrawableBlock(list.get(list.indexOf(db)+2).x(),list.get(list.indexOf(db)+2).y(), list.get(list.indexOf(db)+2).size(), list.get(list.indexOf(db)+2).color(), true, false));
                    list.set(list.indexOf(db) + 3, new DrawableBlock(list.get(list.indexOf(db)+3).x(),list.get(list.indexOf(db)+3).y(), list.get(list.indexOf(db)+3).size(), list.get(list.indexOf(db)+3).color(), true, false));
                    list.set(list.indexOf(db) + 4, new DrawableBlock(list.get(list.indexOf(db)+4).x(),list.get(list.indexOf(db)+4).y(), list.get(list.indexOf(db)+4).size(), list.get(list.indexOf(db)+4).color(), true, false));

                    Parent = new DrawableBlock(db.x(), db.y(), db.size(), db.color(), false, true);
                    list.set(indx, Parent);


                }
            }

        }

    }

    /**
     * move the cursor to the parent if possible
     */
    public void moveUp(){

        for (DrawableBlock db : list){
            if (db.isSelected()) {

                if(list.get(0) != db){
                    for(int i = list.indexOf(db);; i--){

                        if (list.get(i).size() == db.size() * 2){

                            list.set(list.indexOf(db), new DrawableBlock(db.x(), db.y(), db.size(), db.color(), true, false));
                            list.set(i, new DrawableBlock(list.get(i).x(), list.get(i).y(), list.get(i).size(), list.get(i).color(), false, true));
                            break;

                        }


                    }
                }


            }

        }


    }

    /**
     * Move the cursor into the NW child if possible
     */
    public void moveDown(){

        for (DrawableBlock db : list){


            int myIndex;

            if (db.isSelected()){

                if(list.indexOf(db)+1 < list.size() && list.get(list.indexOf(db)+1).size() * 2 == db.size()){

                    myIndex = list.indexOf(db) + 1;
                    list.set(list.indexOf(db), new DrawableBlock(db.x(), db.y(), db.size(), db.color(), db.isVisible(), false));
                    list.set(myIndex, new DrawableBlock(list.get(myIndex).x(), list.get(myIndex).y(), list.get(myIndex).size(), list.get(myIndex).color(), list.get(myIndex).isVisible(), true));
                    break;
                }else{

                    for(int i = list.indexOf(db) -1;; i--){

                        if(db.size() * 2 == list.get(i).size()){

                            myIndex = i + 1;
                            break;
                        }
                    }

                    list.set(list.indexOf(db), new DrawableBlock(db.x(), db.y(), db.size(), db.color(), db.isVisible(), false));
                    list.set(myIndex, new DrawableBlock(list.get(myIndex).x(), list.get(myIndex).y(), list.get(myIndex).size(), list.get(myIndex).color(), list.get(myIndex).isVisible(), true));
                    break;

                }

            }

        }


    }

    /**
     * move the cursor counter clockwise if possible
     */
    public void moveCCW(){

        ccwSwitch = true;


        for (DrawableBlock db : list){

            int nextIndx = list.indexOf(db) - 1;

            if(db.isSelected()){

                if (blockHM.get(db)[0].equals("NW")) {

                    nextIndx = nextIndx + 4;


                    while (true) {

                        if (blockHM.get(list.get(nextIndx))[0].equals("SW") && list.get(nextIndx).size() == db.size()) {

                            list.set(list.indexOf(db), new DrawableBlock(db.x(), db.y(), db.size(), db.color(), db.isVisible(), false));
                            list.set(nextIndx, new DrawableBlock(list.get(nextIndx).x(), list.get(nextIndx).y(), list.get(nextIndx).size(), list.get(nextIndx).color(), true, true));
                            break;
                        } else {
                            nextIndx = nextIndx + 4;
                        }

                    }
                    break;

                }else{

                    if(list.get(nextIndx).size() != db.size()){

                        nextIndx = nextIndx - 4;

                        while (true) {

                            if (list.get(nextIndx).size() == db.size()) {

                                list.set(list.indexOf(db), new DrawableBlock(db.x(), db.y(), db.size(), db.color(), db.isVisible(), false));
                                list.set(nextIndx, new DrawableBlock(list.get(nextIndx).x(), list.get(nextIndx).y(), list.get(nextIndx).size(), list.get(nextIndx).color(), true, true));
                                break;
                            } else {
                                nextIndx = nextIndx - 4;
                            }

                        }

                    }else{

                        list.set(list.indexOf(db), new DrawableBlock(db.x(), db.y(), db.size(), db.color(), db.isVisible(), false));
                        list.set(nextIndx, new DrawableBlock(list.get(nextIndx).x(), list.get(nextIndx).y(), list.get(nextIndx).size(), list.get(nextIndx).color(), true, true));
                        break;

                    }

                    break;
                }
            }
        }


    }

    /**
     * move the cursor in a clockwise way (if possible)
     */
    public void moveCW(){


        cwSwitch = true;

        for (DrawableBlock db : list){

            int nextIndx = list.indexOf(db) + 1;

            if(db.isSelected()){

                if (blockHM.get(db)[0].equals("SW")) {

                    nextIndx = nextIndx - 4;


                    while (true) {

                        if (blockHM.get(list.get(nextIndx))[0].equals("NW") && list.get(nextIndx).size() == db.size()) {

                            list.set(list.indexOf(db), new DrawableBlock(db.x(), db.y(), db.size(), db.color(), db.isVisible(), false));
                            list.set(nextIndx, new DrawableBlock(list.get(nextIndx).x(), list.get(nextIndx).y(), list.get(nextIndx).size(), list.get(nextIndx).color(), true, true));
                            break;
                        } else {
                            nextIndx = nextIndx - 4;
                        }

                    }
                    break;

                }else{

                    if(list.get(nextIndx).size() != db.size()){

                        nextIndx = nextIndx + 4;

                        while (true) {

                            if (list.get(nextIndx).size() == db.size()) {

                                list.set(list.indexOf(db), new DrawableBlock(db.x(), db.y(), db.size(), db.color(), db.isVisible(), false));
                                list.set(nextIndx, new DrawableBlock(list.get(nextIndx).x(), list.get(nextIndx).y(), list.get(nextIndx).size(), list.get(nextIndx).color(), true, true));
                                break;
                            } else {
                                nextIndx = nextIndx + 4;
                            }

                        }

                    }else{

                        list.set(list.indexOf(db), new DrawableBlock(db.x(), db.y(), db.size(), db.color(), db.isVisible(), false));
                        list.set(nextIndx, new DrawableBlock(list.get(nextIndx).x(), list.get(nextIndx).y(), list.get(nextIndx).size(), list.get(nextIndx).color(), true, true));
                        break;

                    }

                    break;

                }
            }

        }


    }

    /**
     * swap/flip the structure from the cursor position
     * @param horizontally if true the flip should happen over the a horizonal plane (i.e,. the top flips with the bottom)
     *                     if false the flip should happen over a vertical plane
     */
    public void flip (boolean horizontally) {

        int indx;

        DrawableBlock NW;
        DrawableBlock NE;
        DrawableBlock SE;
        DrawableBlock SW;

        Color color1;
        Color color2;

        for(DrawableBlock db : list){


            if(getBlockLevel(db) == 1){
                ;
            }else if(db.isSelected() && !horizontally && (list.get(list.indexOf(db)+1).size() == db.size()/2)){

                indx = list.indexOf(db);
                color1 = list.get(indx+2).color(); //NE Color
                color2 = list.get(indx+3).color(); //SE Color

                NE = new DrawableBlock(list.get(indx+2).x(), list.get(indx+2).y(), list.get(indx+2).size(), list.get(indx+1).color(), list.get(indx+2).isVisible(), list.get(indx+2).isSelected());
                NW = new DrawableBlock(list.get(indx+1).x(), list.get(indx+1).y(), list.get(indx+1).size(), color1, list.get(indx+1).isVisible(), list.get(indx+1).isSelected());
                SE = new DrawableBlock(list.get(indx+3).x(), list.get(indx+3).y(), list.get(indx+3).size(), list.get(indx+4).color(), list.get(indx+3).isVisible(), list.get(indx+3).isSelected());
                SW = new DrawableBlock(list.get(indx+4).x(), list.get(indx+4).y(), list.get(indx+4).size(), color2, list.get(indx+4).isVisible(), list.get(indx+4).isSelected());

                list.set(indx+2, NE);

                list.set(indx+1, NW);

                list.set(indx+3, SE);

                list.set(indx+4, SW);


                blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), true, true),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), true, true),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), true, true),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), true, true),new String[]{"SW", "Not Smashed"});

                blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), true, false),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), true, false),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), true, false),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), true, false),new String[]{"SW", "Not Smashed"});

                blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), false, true),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), false, true),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), false, true),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), false, true),new String[]{"SW", "Not Smashed"});

                blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), false, false),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), false, false),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), false, false),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), false, false),new String[]{"SW", "Not Smashed"});


                break;

            }else if(db.isSelected() && horizontally && (list.get(list.indexOf(db)+1).size() == db.size()/2)){

                indx = list.indexOf(db);
                color1 = list.get(indx+1).color(); //NW Color
                color2 = list.get(indx+2).color(); //NE Color

                NW = new DrawableBlock(list.get(indx+1).x(), list.get(indx+1).y(), list.get(indx+1).size(), list.get(indx+4).color(), list.get(indx+1).isVisible(), list.get(indx+1).isSelected());
                SW = new DrawableBlock(list.get(indx+4).x(), list.get(indx+4).y(), list.get(indx+4).size(), color1, list.get(indx+4).isVisible(), list.get(indx+4).isSelected());
                NE = new DrawableBlock(list.get(indx+2).x(), list.get(indx+2).y(), list.get(indx+2).size(), list.get(indx+3).color(), list.get(indx+2).isVisible(), list.get(indx+2).isSelected());
                SE = new DrawableBlock(list.get(indx+3).x(), list.get(indx+3).y(), list.get(indx+3).size(), color2, list.get(indx+3).isVisible(), list.get(indx+3).isSelected());

                list.set(indx+1, NW);
                list.set(indx+4, SW);
                list.set(indx+2, NE);
                list.set(indx+3, SE);


                blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), true, true),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), true, true),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), true, true),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), true, true),new String[]{"SW", "Not Smashed"});

                blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), true, false),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), true, false),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), true, false),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), true, false),new String[]{"SW", "Not Smashed"});

                blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), false, true),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), false, true),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), false, true),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), false, true),new String[]{"SW", "Not Smashed"});

                blockHM.put(new DrawableBlock(NW.x(), NW.y(), NW.size(), NW.color(), false, false),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(NE.x(), NE.y(), NE.size(), NE.color(), false, false),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SE.x(), SE.y(), SE.size(), SE.color(), false, false),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(SW.x(), SW.y(), SW.size(), SW.color(), false, false),new String[]{"SW", "Not Smashed"});

                break;


            }

        }



    }

    /**
     * Rotate the structure from the cursor position
     * @param clockwise true if the rotation should be clockwise and false for ccw
     */
    public void rotate(boolean clockwise){

    }

    /**
     * Merge the children into the parent
     * The majority color of the children becomes the parent's color (or in the case of no majority
     * the NW child becomes the parent color
     * children that are subdivided should first recursively merge so that the parent can determine
     * if there is a majority
     * The children are deleted after the merge happens
     */
    public void merge() {

        Color mergedColor;
        String position;
        String state;

        ArrayList<String> arr = new ArrayList<>();
        for (DrawableBlock db : list){

            if(getBlockLevel(db) == 1){
                ;
            }else if(db.isSelected() && blockHM.get(list.get(list.indexOf(db)+1))[1].equalsIgnoreCase("Not Smashed") && blockHM.get(list.get(list.indexOf(db)+2))[1].equalsIgnoreCase("Not Smashed")
                    && blockHM.get(list.get(list.indexOf(db)+3))[1].equalsIgnoreCase("Not Smashed") && blockHM.get(list.get(list.indexOf(db)+4))[1].equalsIgnoreCase("Not Smashed")){


                arr.add(0, list.get(list.indexOf(db)+1).color().toString());
                arr.add(1, list.get(list.indexOf(db)+2).color().toString());
                arr.add(2, list.get(list.indexOf(db)+3).color().toString());
                arr.add(3, list.get(list.indexOf(db)+4).color().toString());

                String maxOccurredElement = arr.stream()
                        .reduce(BinaryOperator.maxBy((o1, o2) -> Collections.frequency(arr, o1) -
                                Collections.frequency(arr, o2))).orElse(null);

                mergedColor = list.get(list.indexOf(db) + arr.indexOf(maxOccurredElement) + 1).color();

                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+1).x(),list.get(list.indexOf(db)+1).y(), list.get(list.indexOf(db)+1).size(), list.get(list.indexOf(db)+1).color(), false, false),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+2).x(),list.get(list.indexOf(db)+2).y(), list.get(list.indexOf(db)+2).size(), list.get(list.indexOf(db)+2).color(), false, false),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+3).x(),list.get(list.indexOf(db)+3).y(), list.get(list.indexOf(db)+3).size(), list.get(list.indexOf(db)+3).color(), false, false),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+4).x(),list.get(list.indexOf(db)+4).y(), list.get(list.indexOf(db)+4).size(), list.get(list.indexOf(db)+4).color(), false, false),new String[]{"SW", "Not Smashed"});
                blockHM.put(new DrawableBlock(db.x(),db.y(), db.size(), mergedColor, false, false), new String[]{blockHM.get(db)[0], "Smashed"});


                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+1).x(),list.get(list.indexOf(db)+1).y(), list.get(list.indexOf(db)+1).size(), list.get(list.indexOf(db)+1).color(), true, false),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+2).x(),list.get(list.indexOf(db)+2).y(), list.get(list.indexOf(db)+2).size(), list.get(list.indexOf(db)+2).color(), true, false),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+3).x(),list.get(list.indexOf(db)+3).y(), list.get(list.indexOf(db)+3).size(), list.get(list.indexOf(db)+3).color(), true, false),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+4).x(),list.get(list.indexOf(db)+4).y(), list.get(list.indexOf(db)+4).size(), list.get(list.indexOf(db)+4).color(), true, false),new String[]{"SW", "Not Smashed"});
                blockHM.put(new DrawableBlock(db.x(),db.y(), db.size(), mergedColor, true, false), new String[]{blockHM.get(db)[0], "Smashed"});


                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+1).x(),list.get(list.indexOf(db)+1).y(), list.get(list.indexOf(db)+1).size(), list.get(list.indexOf(db)+1).color(), false, true),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+2).x(),list.get(list.indexOf(db)+2).y(), list.get(list.indexOf(db)+2).size(), list.get(list.indexOf(db)+2).color(), false, true),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+3).x(),list.get(list.indexOf(db)+3).y(), list.get(list.indexOf(db)+3).size(), list.get(list.indexOf(db)+3).color(), false, true),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+4).x(),list.get(list.indexOf(db)+4).y(), list.get(list.indexOf(db)+4).size(), list.get(list.indexOf(db)+4).color(), false, true),new String[]{"SW", "Not Smashed"});
                blockHM.put(new DrawableBlock(db.x(),db.y(), db.size(), mergedColor, false, true), new String[]{blockHM.get(db)[0], "Smashed"});


                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+1).x(),list.get(list.indexOf(db)+1).y(), list.get(list.indexOf(db)+1).size(), list.get(list.indexOf(db)+1).color(), true, true),new String[]{"NW", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+2).x(),list.get(list.indexOf(db)+2).y(), list.get(list.indexOf(db)+2).size(), list.get(list.indexOf(db)+2).color(), true, true),new String[]{"NE", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+3).x(),list.get(list.indexOf(db)+3).y(), list.get(list.indexOf(db)+3).size(), list.get(list.indexOf(db)+3).color(), true, true),new String[]{"SE", "Not Smashed"});
                blockHM.put(new DrawableBlock(list.get(list.indexOf(db)+4).x(),list.get(list.indexOf(db)+4).y(), list.get(list.indexOf(db)+4).size(), list.get(list.indexOf(db)+4).color(), true, true),new String[]{"SW", "Not Smashed"});
                blockHM.put(new DrawableBlock(db.x(),db.y(), db.size(), mergedColor, true, true), new String[]{blockHM.get(db)[0], "Smashed"});


                list.set(list.indexOf(db) + 1, new DrawableBlock(list.get(list.indexOf(db)+1).x(),list.get(list.indexOf(db)+1).y(), list.get(list.indexOf(db)+1).size(), list.get(list.indexOf(db)+1).color(), false, false));
                list.set(list.indexOf(db) + 2, new DrawableBlock(list.get(list.indexOf(db)+2).x(),list.get(list.indexOf(db)+2).y(), list.get(list.indexOf(db)+2).size(), list.get(list.indexOf(db)+2).color(), false, false));
                list.set(list.indexOf(db) + 3, new DrawableBlock(list.get(list.indexOf(db)+3).x(),list.get(list.indexOf(db)+3).y(), list.get(list.indexOf(db)+3).size(), list.get(list.indexOf(db)+3).color(), false, false));
                list.set(list.indexOf(db) + 4, new DrawableBlock(list.get(list.indexOf(db)+4).x(),list.get(list.indexOf(db)+4).y(), list.get(list.indexOf(db)+4).size(), list.get(list.indexOf(db)+4).color(), false, false));
                list.set(list.indexOf(db), new DrawableBlock(list.get(list.indexOf(db)).x(),list.get(list.indexOf(db)).y(), list.get(list.indexOf(db)).size(), mergedColor, true, true));


                break;



            }
        }

    }

    /**
     * Compute player 1's score as the length of border matching the given color
     * @param c the color to match
     * @return player 1's score
     */
    public int borderLengthWithColor(Color c) {

        for (DrawableBlock db : list){

            if(!cwSwitch && !ccwSwitch && !visited.contains(db) && db.isVisible() && db.color().equals(c)  && (((db.x() == 0)) || (db.y() == 0) || (db.x() + db.size() == MAX_SIZE) || (db.y() + db.size() == MAX_SIZE))){

                //Corners
                if((blockHM.get(db)[0].equalsIgnoreCase("NW") && db.x() == 0 && db.y() == 0) || (blockHM.get(db)[0].equalsIgnoreCase("NE") && db.x() + db.size() == MAX_SIZE && db.y() == 0)
                        || (blockHM.get(db)[0].equalsIgnoreCase("SE") && db.x() + db.size() == MAX_SIZE && db.y() + db.size() == MAX_SIZE) || (blockHM.get(db)[0].equalsIgnoreCase("SW") && db.x() == 0 && db.y() + db.size() == MAX_SIZE)){


                    visited.add(db);
                    visited.add(new DrawableBlock(db.x(), db.y(), db.size(), db.color(), true, false));
                    scoreP1 += db.size() * 2;
                    isACorner++;

                // Edges
                }else{

                    visited.add(db);
                    visited.add(new DrawableBlock(db.x(), db.y(), db.size(), db.color(), true, false));
                    scoreP1 += db.size();
                }

            }

        }


        return scoreP1;
    }

    /**
     * Compute player 2's score (as the rounded length of the diagonal matching the given color)
     * @param c the target color
     * @return player 2's score
     */
    public int diagonalWithColor(Color c) {
        return 0;
    }

    /**
     * @return the List of drawable blocks, so they can be rendered to screen
     */
    public ArrayList<DrawableBlock> getBlocks() {
        return list;
    }




    //Helper methods
    public int getMinSize(){
        return sizes.stream().min(Integer::compare).get();
    }

    public int getDeepestLevel(){

        int minSize = getMinSize();
        int result = (int)(Math.log(minSize) / Math.log(2));
        return (startingPower - result);

    }

    public int getBlockLevel(DrawableBlock block){

        int result = (int)(Math.log(block.size()) / Math.log(2));
        return (startingPower - result);

    }

}

